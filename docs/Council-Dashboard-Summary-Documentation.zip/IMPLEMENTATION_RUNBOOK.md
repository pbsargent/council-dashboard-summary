# Council Dashboard Summary Implementation Runbook

Last reviewed: 2026-08-23

This runbook is for a technical handoff. It explains what another analyst or engineer needs to acquire data, recreate a similar static dashboard, run the daily refresh, validate outputs, and publish through GitHub Pages.

Use this with:

- `README.md` for project orientation
- `DASHBOARD_DATA_DICTIONARY.md` for source fields and calculations
- `tools/build_human_data_guide.py` for the reader-facing DOCX/PDF guide
- `update_daily.zsh`, `refresh_monday_data.py`, and `work/commissioner_site/build_site.py` for the actual refresh implementation

## 1. What Must Exist

### Local Runtime

The current automation uses the Codex-bundled Python runtime:

```text
/Users/petersargent/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
```

Required Python capabilities:

- `openpyxl` for reading Excel workbooks
- `python-docx` for generating the human-readable DOCX guide
- Standard library modules for JSON, paths, dates, HTTP, and subprocess-safe file handling

For a similar dashboard on another machine, either install equivalent Python packages in a normal virtual environment or update the scripts to point at that machine's Python.

### GitHub Pages Repository

The active publishing repository is:

```text
/Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary
https://github.com/pbsargent/council-dashboard-summary
```

GitHub Pages deploys a verified artifact through `.github/workflows/deploy-pages-payload.yml`. The `main` branch retains source code; the browser-facing artifact contains static HTML, CSS, JavaScript, images, and current JSON.

Minimum static files for a similar dashboard:

- `index.html`
- `council-dashboard-summary.css`
- `panel-help.js` for active `?` panel help popovers
- Dashboard JavaScript files
- `assets/`
- `data/latest.json`
- Optional `data/monday-latest.json`
- Optional `renewal-board/` static subpage and `renewal-board/data.js`
- Optional `docs/` artifacts

This repository also carries operational helper scripts:

- `tools/inject_unit_youth_trends.py` injects the workbook `Units-Youth` tab into published dashboard JSON.
- `publish_site_only.zsh` publishes prepared local site changes without rebuilding source workbooks.
- `Publish Council Dashboard.command` is the double-click wrapper for `publish_site_only.zsh`.

Separate Commissioner Dashboard portal:

```text
/Users/petersargent/CACDashboardPlatform/sites/council-commissioner-dashboard
https://github.com/pbsargent/council-commissioner-dashboard
https://pbsargent.github.io/council-commissioner-dashboard/
```

That repository is a small static portal into the Council Dashboard Summary and reads the same canonical `data/latest.json`. It is not a separate embedded-data dashboard.

### Persistent Camping Readiness Build Contract

Future builds and publishes must preserve these two data-driven detail pages:

- `camping-readiness.html`: **Pack Camping Readiness**, classifying BALOO leadership depth as Gap, Fragile, Preferred Depth, or Unknown and showing current Hazardous Weather roster coverage separately.
- `troop-camping-readiness.html`: **Troop Camping Readiness**, classifying IOLS-trained Scoutmaster/Assistant Scoutmaster depth as Gap, Fragile, Preferred Depth, or Unknown and showing current Hazardous Weather roster coverage separately. An explicit IOLS field controls when present; otherwise the absence of mandatory code `S11` is the fallback signal.

Both pages belong under **People & Readiness**, after Training and SYT. Commissioner Portal belongs under **Overview**, before Council Comparison. The camping-readiness pages must not be moved back under Unit Health & Renewal. Their page eyebrow and back link must continue to identify `people.html` as the parent page. Each table must include every reviewed Pack or Troop so Preferred Depth remains selectable. The Status selector must offer All statuses, Gap, Fragile, Preferred Depth, and Unknown; the Hazardous Weather selector must remain separate so the two signals can be combined without changing their definitions.

`unit-level.html` must load the same `outdoor-readiness.js` classification. For Packs and Troops, Unit-Level Detail shows the matching Camping Readiness status in the KPI strip and repeats it in Training Readiness with qualification count and Hazardous Weather context. A missing Training-tab unit match displays Unknown. Crews, Ships, and Posts do not receive a camping-readiness KPI.

This is enforced in `tools/validate_site_structure.py` through `DETAIL_PAGES`, `NAVIGATION_ROUTES`, and `NAVIGATION_HIERARCHY`. The scheduled updater runs that validator after loading the current site code and again immediately before publication. A future build that removes either page, changes its route or page identity, or moves it to the wrong navigation parent must fail before publishing.

### Persistent BeAScout PIN Freshness Contract

`work/commissioner_site/build_site.py` joins the complete unit-level metric population to the main dashboard workbook's `Units` and `Pin` tabs and publishes matched rows as `dashboard.unit_pin_statuses`. The display state is calculated from the dated workbook's report as-of date:

- `Stale`: more than 12 months have passed since the matched `lastmodifieddate`, or that date is blank or unusable. Operationally, the implementation uses a date earlier than the same calendar date one year before the report as-of date.
- `Active` or `Inactive`: the matched date is on or after that cutoff, so the source `pinstatus` is retained.
- `n/a`: no PIN record is matched to the unit; this is not an inactive or stale classification.

Use this one classification in the Unit Health page's complete Unit Follow-up metric bands, the first KPI on Unit-Level Detail, and the Unit Health Funnel. The funnel numerator counts matched `Inactive` and `Stale` rows after the master program filter. Its denominator is all membership-dashboard units in that view, including units without a matched PIN. The percentage therefore can differ from a calculation that divides only by `dashboard.unit_pin_statuses.length`.

The builder also publishes four Boolean completeness flags on each matched `unit_pin_statuses` row: `pin_status_complete`, `pin_contact_complete`, `pin_meeting_complete`, and `pin_details_complete`. Required PIN Details is true only when status, contact name plus either email or phone, meeting location, and meeting details are present. Website, fee, fundraising, and availability are not counted, and freshness remains a separate PIN Currency measure. The PIN Status & Completeness page divides complete matched rows by all tracked units in the selected district/program view, including unmatched units. Do not publish the underlying contact or meeting values; only the Boolean flags are allowed in public JSON.

District PIN Detail joins those privacy-safe PIN rows back to the complete unit-level population by normalized district and unit identity. Its expanded district unit rows inherit the active program, Service Area, District, and follow-up focus; sort unmatched, Stale, Inactive, incomplete, and complete Active units in that order; and expose only missing categories. Unit links pass the public `unit_id` query parameter so Unit-Level Detail selects the intended record.

District Performance Operational Detail district rows use the same complete unit-level population after the master program filter. Expanding a Service Area exposes district rows; expanding a district exposes unit health, youth movement, metric, retention, privacy-safe PIN state, assignment presence, SYT, and training, sorted from the lowest unit metric upward. Each expanded unit has a direct Unit-Level Detail link using its public `unit_id`. Keep the nested unit table bounded and scrollable, preserve 11 columns in scorecard summary rows, and never display private PIN contact or meeting values.

Overview's Signals to Watch groups filtered matched rows into Active, Inactive, and Stale, derives unmatched as tracked units minus matched rows, and shows PIN Currency using the same denominator. The Overview Explore panel links directly to `pin-status.html`. Unit-Level Detail stores the complete matched `unit_pin_statuses` row and renders separate PIN status and Required PIN Details badges in Commissioner Context; do not infer completeness from freshness or vice versa.

The focused safeguards are `tools/test_pin_status.py`, `tools/test_pin_status_page.js`, `tools/test_unit_health_pin_funnel.js`, `tools/test_unit_level_pin_status.js`, and the PIN assertions in `tools/validate_site_structure.py`. Keep the Help page, Markdown data dictionary, reader-facing DOCX/PDF guide, and documentation ZIP synchronized with this contract.

## 2. Data Acquisition Requirements

The dashboard does not read Google Drive, OneDrive, or monday.com from the browser. Data is acquired by local scripts, converted to JSON in an isolated staging tree, checksum-verified, and served through a GitHub Pages artifact.

### Google Shared Drive Access

The refresh account must have local Google Drive for desktop access to these shared drives:

| Shared drive | Required files | Used by |
| --- | --- | --- |
| `Council Dashboard Reports` | Newest `*_Dashboard - CAC.xlsx` for the main council dashboard; newest `*_CAC - Unit Metric Scorecard.xlsx` for Unit Level detail | Main council dashboard data and Unit Level dashboard data |
| `Council Metric Reports` | Newest `*_CST7.xlsx` | Council Service Territory comparison |
| `Council monday.com Reports` | Newest `*monday-export.xlsx` | monday.com operating detail and TAY |

Current local base path pattern:

```text
/Users/petersargent/Library/CloudStorage/GoogleDrive-peter@imetpetersargent.com/Shared drives/<drive name>
```

If another user or machine has a different Google Drive account path, update the default paths in:

- `work/commissioner_site/build_site.py`
- `refresh_monday_data.py`
- `update_daily.zsh` if wrapper paths change

### Source Workbook Naming

The automated selectors depend on filename patterns:

| Source | Pattern |
| --- | --- |
| Council dashboard workbook | `*_Dashboard - CAC.xlsx` only |
| Unit Level Metrics workbook | `*_CAC - Unit Metric Scorecard.xlsx` only |
| CST workbook | `*_CST7.xlsx` |
| monday.com export workbook | `*monday-export.xlsx` |

The scripts choose the newest matching file by modification time and filename. Keep the council dashboard workbook and Unit Level Metrics patterns separate even when both files live in `Council Dashboard Reports`. The CAC dashboard deck builder must never use a Unit Level Metrics workbook; that workbook does not contain the `Membership` sheet and will fail the build. If naming changes, update the glob patterns in the refresh scripts.

### Non-Workbook Source: Service Areas

Service Area grouping and district volunteer leadership are controlled by the authoritative monday.com `Field Service / Service Areas` board (board `18420160563`). Before each daily build, `work/renewal_recreation/refresh_service_area_hierarchy.py` captures the board hierarchy and its `Volunteer Chair` and `Commissioner` columns. The council snapshot and renewal-board builder both read that same run-specific capture.

Current mapping:

| Service Area | Field Director | Districts |
| --- | --- | --- |
| Northern | Justin Brundin | Bee Cave, Chisholm Trail, Hill Country, North Shore |
| Central | Vicki Rosengarten | Armadillo, Colorado River, Exploring, San Gabriel, Thunderbird |
| Southern | Ed Grune | Live Oak, Sacred Springs, Waterloo |

If the board structure changes, update the hierarchy refresher's expected column and reference-type mappings. Ordinary Service Area, Volunteer Chair, and Commissioner changes require no code edit; the next daily build reads them from monday.com.

### Required Workbook Sheets

Council dashboard workbook:

- `Membership`
- `Unit Metric Compare`
- `Glance`
- `Training Dive`
- `Objectives - Commissioners`
- `Unit Metrics`
- `Assigned`
- `Pin`
- `Units`
- `Training`
- `Training Codes`
- `Commissioners`
- `Units-Youth`

CST workbook:

- `Membership`
- `Unit Metric Compare`
- `Glance`

monday.com export workbook:

- `Overview`
- `New unit Hot Prospects`
- `2026 Unit Renewal`
- `Schools`
- `Popcorn Committments`

The renewal board subpage also reads the `2026 Unit Renewal` sheet and joins it to the Council dashboard `Units` and `RenewNewDrop` tabs through `work/renewal_recreation/build_renewal_board_data.py`.

The Membership Intelligence Unit & Youth Trends section reads the `Units-Youth` tab through `tools/inject_unit_youth_trends.py`. This injector runs after the external workbook builder writes `data/latest.json` and the dated archive, because the external builder lives outside this repo and is not the only place the GitHub Pages refresh is coordinated.

`DASHBOARD_DATA_DICTIONARY.md` lists the important fields used from each sheet. Header changes in these workbooks are the most likely cause of a refresh failure or silent metric drift.

### monday.com API Token

The preferred monday.com input is the daily workbook export for Prospects, Renewals, Schools, and Popcorn. If the workbook is unavailable, the API fallback maintains board summaries and privacy-safe Popcorn rows; the other detailed board views remain workbook-dependent.

Token locations currently used:

- `refresh_monday_data.py` default: `/Users/petersargent/Documents/Monday-Com-API-Token.txt`
- Active wrapper default: `/Users/petersargent/Documents/06 Personal, Legal, and Sensitive/Sensitive - Move to Password Manager/Monday-Com-API-Token.txt`
- Active wrapper override: set `MONDAY_API_TOKEN_FILE`

Accepted token file format:

```text
actual_token_value
```

or:

```text
MONDAY_API_TOKEN=actual_token_value
```

Required API access:

- Read access to the Capitol Area Council monday.com workspace
- Read access to the boards configured in `refresh_monday_data.py`
- Ability to query board items and column values

Current board IDs are embedded in `refresh_monday_data.py`.

## 3. Build and Refresh Flow

The daily refresh is coordinated by:

```text
/Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/update_daily.zsh
```

The installed LaunchAgent runs:

```text
/bin/zsh -lc 'COUNCIL_DASHBOARD_SUMMARY_REPO=/Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary /Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/update_daily.zsh'
```

The operational order is:

1. Run `work/commissioner_site/build_site.py`.
2. Locate the newest `*_Dashboard - CAC.xlsx` Council dashboard workbook.
3. Exclude `*_CAC - Unit Metric Scorecard.xlsx` from the CAC dashboard source selection even if it has the newest modified time.
4. Locate the newest CST workbook.
5. Generate `data/latest.json`.
6. Generate dated archive JSON, for example `data/2026-06-28.json`.
7. Run `tools/inject_unit_youth_trends.py` against `data/latest.json` and `data/YYYY-MM-DD.json`.
8. Run `refresh_monday_data.py`.
9. Prefer the newest monday.com export workbook.
10. Fall back to monday.com API if workbook acquisition fails.
11. Generate or preserve `data/monday-latest.json`.
12. Locate the newest validated `*_CAC - Unit Metric Scorecard.xlsx` captured by `CACDashboardAutomation`.
13. Rebuild `data/unit-level-latest.json` and `data/unit-level-latest.js` with `tools/build_unit_level_dashboard.py`.
14. Copy refreshed JSON and Unit Level data to the local preview site when present.
15. Rebuild `renewal-board/data.js` when the renewal board subpage exists.
16. Copy the renewal-board data bundle to the local preview site when present.
17. Fetch `origin/main`, require a clean source checkout, and fast-forward it.
18. Revalidate the isolated staged site and confirm no second writer changed `origin/main`.
19. Package the current static tree and calculate its SHA-256 checksum.
20. Replace the rolling payload and deploy it through the repository's GitHub Pages workflow.

The website code is not regenerated daily. JSON data files and the renewal-board data bundle update unless a human commits HTML/CSS/JS changes.

The installed scheduled launcher is `/Users/petersargent/CACDashboardPlatform/tools/daily_pipeline.zsh`. The site updater should contain these Unit & Youth injector lines:

```zsh
UNIT_YOUTH_INJECTOR="${COUNCIL_DASHBOARD_SUMMARY_UNIT_YOUTH_INJECTOR:-${SUMMARY_REPO}/tools/inject_unit_youth_trends.py}"
require_file "$UNIT_YOUTH_INJECTOR"
"$PYTHON" "$UNIT_YOUTH_INJECTOR" "${SUMMARY_REPO}/data/latest.json" "${SUMMARY_REPO}/data/${SNAPSHOT_DATE}.json"
```

If those lines are missing, restore `update_daily.zsh` from the consolidated
platform source; the site repository no longer installs its own scheduler.

The Commissioner Dashboard portal is published by:

```text
/Users/petersargent/CACDashboardPlatform/work/commissioner_site/update_and_publish_github.zsh
```

The sole 8:30 AM platform job invokes this publisher after the Council site. It
writes an isolated portal staging tree and deploys it as a verified Pages
artifact. An unchanged payload is skipped automatically.

## 4. Manual Refresh

Use a manual refresh when validating a new source workbook, testing a path change, or recovering from a missed scheduled run.

Recommended command:

```bash
COUNCIL_DASHBOARD_SUMMARY_REPO=/Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary /Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/update_daily.zsh
```

Optional monday.com token override:

```bash
MONDAY_API_TOKEN_FILE=/path/to/Monday-Com-API-Token.txt \
COUNCIL_DASHBOARD_SUMMARY_REPO=/Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary \
/Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/update_daily.zsh
```

Manual council/CST build only:

```bash
/Users/petersargent/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  /Users/petersargent/Documents/Codex/Daily\ Uodate/work/commissioner_site/build_site.py \
  --output-dir /tmp/council-dashboard-test
```

Manual monday.com workbook refresh only:

```bash
/Users/petersargent/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  /Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/refresh_monday_data.py \
  --token-file /path/to/Monday-Com-API-Token.txt \
  --output /tmp/monday-latest.json
```

Manual Unit & Youth trend injection only:

```bash
/Users/petersargent/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  /Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/tools/inject_unit_youth_trends.py \
  /Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/data/latest.json \
  /Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/data/$(date +%F).json
```

This reads the workbook path already stored in each JSON file at `dashboard.source`, then extracts the `Units-Youth` tab into `dashboard.unit_youth_trends`.

## 5. Schedule and Logs

Installed LaunchAgent:

```text
/Users/petersargent/Library/LaunchAgents/com.cac.dashboard.macpro-daily.plist
```

Current schedule:

```text
Daily at 9:05 AM local machine time
```

Related daily automation sequence:

| Time | LaunchAgent | Purpose |
| --- | --- | --- |
| 8:30 AM | `com.cac.dashboard.sync` | Download/sync the Council dashboard workbook |
| 8:35 AM | `com.cac.dashboard.cst7sync` | Download/sync the CST7 workbook |
| 8:40 AM | `com.cac.dashboard.refresh` | Build branded CAC dashboard deck/PDF |
| 8:45 AM | `com.cac.dashboard.unitmetricrefresh` | Build UnitMetricCompare deck/PDF |
| 8:50 AM | `com.cac.dashboard.githubpublish` | Publish the Commissioner Dashboard portal |
| 8:55 AM | `com.pbsargent.membership-operating-reports.daily` | Export monday.com workbook and build operating deck/PDF |
| 9:05 AM | `com.cac.dashboard.macpro-daily` | Build and publish Council Dashboard Summary JSON |

Current log files:

```text
/Users/petersargent/Documents/Codex/Daily Uodate/outputs/council-dashboard-summary-github/update_daily.log
/Users/petersargent/Documents/Codex/Daily Uodate/outputs/council-dashboard-summary-github/update_daily.err.log
```

Useful checks:

```bash
launchctl print gui/$(id -u)/com.cac.dashboard.macpro-daily
tail -50 "/Users/petersargent/Documents/Codex/Daily Uodate/outputs/council-dashboard-summary-github/update_daily.log"
tail -50 "/Users/petersargent/Documents/Codex/Daily Uodate/outputs/council-dashboard-summary-github/update_daily.err.log"
```

## 6. Publication and Cache Behavior

Source changes are pushed normally to:

```text
origin main
```

The Pages repositories use normal linear source history. Daily generated data
does not enter Git history. The consolidated publisher starts from the current
remote source commit, verifies that no second writer changed GitHub during
generation, replaces one rolling payload, and waits for the Pages workflow to
succeed.

Public site:

```text
https://pbsargent.github.io/council-dashboard-summary/
```

JSON fetches use `cache: "no-store"`, so daily data updates should appear without changing script filenames. HTML/CSS/JS changes may require cache-busting query strings, such as:

```html
<script src="council-dashboard-summary.20260626-tay-kpi.js?v=20260628-viewer-tz2"></script>
```

Use cache busting after code changes, not for ordinary data-only refreshes.

Most major panels include circular `?` controls. The text lives in the HTML button `title` attributes, while `panel-help.js` removes the native title tooltip and displays a custom hover/focus/click popover. After changing panel help behavior or styling, bump the `panel-help.js` and CSS query strings.

For manual site-only publishing after page, script, stylesheet, docs, or already-prepared data changes, run:

```bash
cd /Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary
./publish_site_only.zsh "Publish site updates"
```

Or double-click:

```text
/Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/Publish Council Dashboard.command
```

This path rejects generated-data changes, commits and pushes source changes, then invokes the normal refresh so the source update is combined with current data in a verified Pages artifact.

## 7. Validation Checklist

After any refresh or rebuild, check:

- `data/latest.json` exists and has the expected `generated_date`.
- A dated archive JSON exists for the same generated date.
- `data/monday-latest.json` exists or the monday.com failure was expected and the previous file was intentionally preserved.
- `data/unit-level-latest.json` and `data/unit-level-latest.js` exist, match, and reference the newest validated Unit Level Metrics capture.
- Unit Level renewal names remain first name plus last initial; the intake job must reject the workbook otherwise.
- `renewal-board/data.js` exists and its metadata references the newest renewal and dashboard workbook inputs.
- Council dashboard source name matches the newest `*_Dashboard - CAC.xlsx` and is not a `*_CAC - Unit Metric Scorecard.xlsx` Unit Level Metrics file.
- CST source name matches the newest `*_CST7.xlsx`.
- monday.com source workbook matches the newest `*monday-export.xlsx`, unless API fallback was used.
- `dashboard.districts` includes the 12 official districts.
- Council youth, units, training rows, commissioner rows, prospects, renewals, school rows, and Popcorn participation counts are plausible.
- Home page loads without JavaScript errors.
- Training, SYT, monday.com, Popcorn, unit metrics, and membership detail pages load.
- Pack Camping Readiness and Troop Camping Readiness load, remain under People & Readiness, and read the current `dashboard.training_people` snapshot through `outdoor-readiness.js`.
- Both pages classify qualification depth as zero (Gap), one (Fragile), two-plus (Preferred Depth), or unclassifiable (Unknown), and their default tables include all reviewed units.
- The Status filter returns those four leadership-depth categories. Hazardous Weather is independently filterable as Current or Gap and can be combined with Status, District, Sort, and Search.
- Unit-Level Detail shows the same Camping Readiness status for Packs and Troops in both its KPI strip and Training Readiness row; unmatched Training-tab units show Unknown.
- `dashboard.unit_pin_statuses` contains the expected matched unit-level PIN population and only `Active`, `Inactive`, or `Stale` display states; an unmatched unit renders `n/a` in Unit Follow-up and Unit-Level Detail.
- A PIN row is `Stale` when more than 12 months have passed since its last update, or its update date is blank or unusable. The boundary date exactly one year before the dated report's as-of date is not stale.
- Unit Health Funnel `Inactive + stale PINs` equals the filtered count of both states and divides by all membership-dashboard units in the selected program view, including unmatched `n/a` units in the denominator.
- District Performance → District Scorecard shows `PIN Currency` in place of the former `At Risk` column. It equals matched current `Active` or `Inactive` PIN rows divided by all tracked units in the selected district/program view; `Stale` and unmatched `n/a` units remain in the denominator. Service Area rows aggregate counts before calculating the percentage.
- District Performance → PIN Status & Completeness shows PIN status, currency, and Required PIN Details by district. Required PIN Details equals matched rows with all essential completion flags divided by all tracked units; the public JSON contains only Boolean completion flags and no PIN contact or meeting values. Expand a district to verify the individual-unit status/completeness rows and their Unit-Level Detail links under every follow-up focus.
- Overview → Signals to Watch includes the filtered PIN state counts and PIN Currency, and Overview → Explore links to PIN Status & Completeness.
- Unit-Level Detail → Commissioner Context shows separate PIN status and Required PIN Details badges from the matched privacy-safe row.
- Unit Follow-up Metric bands `0-2`, `3`, and `4-5` display only rows within the selected band and retain the matching PIN state.
- Neither page represents campout approval or claims that roster data proves two-deep, female-leader, registration, or actual-attendance compliance.
- Renewal board page loads, honors light/dark mode, and links back to the Council Summary page.
- Panel `?` controls display active help popovers on hover, focus, or click/tap.
- Service Area and District filters both populate and work on the home page, Training, SYT, Unit Metrics, Membership, monday.com detail, Popcorn, and Commissioner Dashboard.
- Popcorn rows reconcile to the daily workbook extraction (or API fallback), participation equals committed rows divided by all rows, and no contact name, email, or phone fields are published.
- Lower-left freshness timestamp displays in the viewer timezone.
- `dashboard.service_area_source` is present, and all 12 official districts have `service_area`.
- `dashboard.council.unit_commissioners` counts unique Unit Commissioner people, not duplicate role rows.
- `dashboard.unit_youth_trends` exists and includes `new_units`, `new_youth`, `total_youth`, and `total_units`.
- Each `dashboard.unit_youth_trends.series.*.values` object includes `2026`, `2025`, and `2024`.
- Membership Intelligence shows four Unit & Youth grouped bar charts and each chart's `?` button expands a 2026/2025/2024 data table.
- Git status is clean after a successful scheduled publish, except for intentionally ignored local files.

Suggested public checks:

```bash
curl -I https://pbsargent.github.io/council-dashboard-summary/
curl -I https://pbsargent.github.io/council-dashboard-summary/data/latest.json
curl -I https://pbsargent.github.io/council-dashboard-summary/data/monday-latest.json
```

## 8. Common Failure Modes

| Symptom | Likely cause | What to check |
| --- | --- | --- |
| Missing `latest.json` | Council/CST builder failed | Google Drive path, workbook names, required sheets |
| monday.com page is stale | monday workbook missing and API fallback failed | Export workbook, token path, API access |
| 18 monday.com districts appear | Operational labels included | Official-district filtering logic and source labels |
| School market context is blank | Schools rows missing or district labels do not match official districts | `boards.schools.rows`, `scouting_district`, official district list |
| Pages artifact deployment fails | GitHub authentication, checksum mismatch, workflow failure, or a second source writer | `gh auth status`, Actions run, rolling release assets, remote `origin/main` |
| Page still shows old code | Browser or CDN cached JavaScript | Bump script query string and republish |
| `?` help does not open | Missing/stale `panel-help.js` or cached CSS | Confirm `panel-help.js` is loaded, CSS has `.panel-help-tooltip`, and query strings were bumped |
| Future-looking timestamp | Source timezone interpreted incorrectly | Check whether timestamp has `Z`/offset or should be treated as America/Chicago |
| Service Area filter missing or empty | Stale JavaScript/HTML or missing mapping in JSON | Check cache-busted script URL, `dashboard.service_areas`, and `service_area` fields |
| CAC deck fails with `Worksheet Membership does not exist` | CAC deck builder selected a Unit Level Metrics workbook instead of the `Dashboard - CAC` workbook | Verify `update_from_google_folder.zsh` filters to `*_Dashboard - CAC.xlsx`; confirm the log line `Newest workbook:` shows the dated Dashboard file, not `*_CAC - Unit Metric Scorecard.xlsx` |
| Unit & Youth trends missing/stale | Injector not present in scheduled launcher or `Units-Youth` tab changed layout | Check `UNIT_YOUTH_INJECTOR` lines in `/Users/petersargent/CACDashboardPlatform/sites/council-dashboard-summary/update_daily.zsh`, run `tools/inject_unit_youth_trends.py`, verify `dashboard.unit_youth_trends` |
| PIN status is missing or unexpectedly `n/a` | Unit identity did not join between Unit Metrics, Units, and Pin tabs | Check district/unit identity fields, `dashboard.unit_pin_statuses`, and the selected unit's Unit ID in the source workbook |
| PIN funnel count is correct but its percentage looks lower | The numerator uses matched Inactive + Stale rows while the denominator uses all membership-dashboard units | Reconcile the numerator to `unit_pin_statuses`, then divide by the displayed Total units value rather than by matched PIN rows only |
| Membership trend charts show legend but no 2024 values | Published JSON lacks 2024 series or stale script/data cache | Verify `dashboard.unit_youth_trends.series.*.values.2024`, refresh page, confirm cache-busted `membership-detail.20260626.js` |
| Commissioner publisher diverges | A legacy checkout still has production push access | Confirm only `/Users/petersargent/CACDashboardPlatform/sites/council-commissioner-dashboard` can push |
| Workbook quality concern | Concentrated formula errors in source workbook | Scan actual Excel error cells; current 2026-07-01 CAC workbook has concentrated errors in `Renewal Prep` and `Objectives - Commissioners`, not a mostly-error workbook |

## 9. Rebuilding a Similar Dashboard

For a similar council or organization:

1. Create a static GitHub Pages repository.
2. Decide the canonical source workbooks and daily export process.
3. Define workbook filename patterns and required sheets.
4. Build a local extractor that writes stable JSON.
5. Keep calculations in source code and document them in a data dictionary.
6. Build the dashboard against the JSON, not directly against private data sources.
7. Add a daily automation that refreshes JSON and publishes the current static tree to GitHub Pages.
8. Add validation checks for source freshness, row counts, official district labels, and key KPI plausibility.
9. Use cache-busted script URLs after code changes.
10. Keep a human-readable source/calculation guide aligned with the technical dictionary.

## 10. Security and Privacy Notes

- Do not commit monday.com API tokens.
- Do not expose private Google Drive local paths in browser-facing data unless acceptable for the audience.
- Do not put sensitive person-level fields into public JSON unless the dashboard audience is authorized for them.
- Treat every file in the staged Pages artifact, including `data/`, as public once deployed.

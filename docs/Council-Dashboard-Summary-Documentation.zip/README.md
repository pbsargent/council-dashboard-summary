# Council Dashboard Summary

Static web dashboard for Capitol Area Council summary metrics, monday.com operating snapshots, CST comparison data, and source workbook links.

The GitHub Pages entry point is `index.html`.

Public URLs:

- Council Dashboard Summary: https://pbsargent.github.io/council-dashboard-summary/
- Commissioner Dashboard portal: https://pbsargent.github.io/council-commissioner-dashboard/

Data sources and calculations are documented in `DASHBOARD_DATA_DICTIONARY.md`.

Technical setup, data acquisition, automation, validation, and rebuild guidance are documented in `IMPLEMENTATION_RUNBOOK.md`.

Freshness timestamps shown in the dashboard are rendered in the viewer browser's local timezone. No-offset Council dashboard timestamps are interpreted as America/Chicago source time before display.

The scheduled daily updater runs from the launchd-safe working copy at `/Users/petersargent/CouncilDashboardSummaryRepo`, using `/Users/petersargent/CouncilDashboardSummaryUpdate.zsh`. The checkout under `outputs/council-dashboard-summary-github` remains useful for development, but it is not the active scheduled GitHub Pages working copy.

Membership Intelligence uses the Council dashboard workbook `Units-Youth` tab for councilwide Unit & Youth Trends. The daily updater injects this tab into `dashboard.unit_youth_trends` through `tools/inject_unit_youth_trends.py` after the external workbook builder writes JSON.

The Unit Level Dashboard uses the latest dated `CAC - Unit Metric Scorecard.xlsx` captured by `CACDashboardAutomation`. The daily publisher rebuilds `data/unit-level-latest.json` and `data/unit-level-latest.js` through `tools/build_unit_level_dashboard.py` before publishing.

The scheduled Council Summary publisher uses the `CACDashboardAutomation/.venv` Python environment and does not require the Codex application or a Codex-managed runtime to be running.

Both the Council Summary and the separate Commissioner Dashboard portal now use historyless publishing. Each publish replaces the public `main` branch with one current root commit using `--force-with-lease`, so the repos do not grow by one commit per daily refresh.

For manual site-only publishing after HTML/CSS/JS/data edits, use `publish_site_only.zsh` or double-click `Publish Council Dashboard.command`. This path does not rebuild source workbooks.

Service Area filtering is based on Bill Kohl's authoritative 2026-06-30 `Districts and Service Area` email. The mapping is applied during JSON generation and is available alongside District filters across the major dashboard pages.

Popcorn Commitments is included as a home-page participation KPI and as a dedicated operational page with a collapsed-by-default Service Area → District → Unit hierarchy. Its rows refresh from the normal daily monday.com workbook, with the API retained as a fallback. The public Popcorn snapshot contains unit-level commitment, goal, sales, onboarding, and training fields but excludes contact names, email addresses, and phone numbers.

For a more shareable reader-facing guide, see:

- `docs/Council-Dashboard-Summary-Source-and-Calculation-Guide.docx`
- `docs/Council-Dashboard-Summary-Source-and-Calculation-Guide.pdf`
